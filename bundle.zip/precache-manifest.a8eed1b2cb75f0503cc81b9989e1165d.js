self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9929440193ed64d9b0165cb103a49baf",
    "url": "/index.html"
  },
  {
    "revision": "70fd98687ee1877a70cc",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "70fd98687ee1877a70cc",
    "url": "/static/js/2.c4613fcf.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.c4613fcf.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9ee0b22490fa70d5e224",
    "url": "/static/js/main.dc3727e3.chunk.js"
  },
  {
    "revision": "94a299a1b204df77b7df",
    "url": "/static/js/runtime-main.adca9209.js"
  }
]);